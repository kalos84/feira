-- ============================================================
-- FEIRA · schema do piloto
-- Postgres / Supabase
-- ============================================================

drop table if exists eventos cascade;
drop table if exists sessoes cascade;
drop table if exists itens_lista cascade;
drop table if exists listas cascade;
drop table if exists categoria_secao cascade;
drop table if exists produtos cascade;
drop table if exists secoes cascade;
drop table if exists corredores cascade;
drop table if exists lojas cascade;

create table lojas (
  id            uuid primary key default gen_random_uuid(),
  nome          text not null,
  endereco      text,
  cidade        text default 'Palmas',
  lat           double precision,
  lng           double precision,
  caixas        int  default 4,
  nota          numeric(2,1) default 4.5,
  achabilidade  int default 90,
  ativa         boolean default true,
  criada_em     timestamptz default now()
);

-- um corredor e' um no' do grafo; "ordem" e' a sequencia fisica da rota
create table corredores (
  id        uuid primary key default gen_random_uuid(),
  loja_id   uuid not null references lojas(id) on delete cascade,
  codigo    text not null,             -- C7, P1...
  nome      text not null,             -- "Massas e molhos", "Hortifruti"
  perimetro boolean default false,     -- anel externo (pereciveis)
  ordem     int not null,              -- sequencia fisica na loja
  unique (loja_id, codigo)
);

create table secoes (
  id           uuid primary key default gen_random_uuid(),
  corredor_id  uuid not null references corredores(id) on delete cascade,
  nome         text not null,
  prateleira   int default 3,          -- 1 (chao) a 5 (alto); 3 = altura dos olhos
  lado         text default 'A',       -- A ou B do corredor
  ordem        int not null            -- posicao ao longo do corredor
);

create table produtos (
  id         uuid primary key default gen_random_uuid(),
  loja_id    uuid not null references lojas(id) on delete cascade,
  ean        text,
  descricao  text not null,
  categoria  text not null,
  preco      numeric(10,2) not null default 0,
  estoque    int default 10,
  unique (loja_id, descricao)
);

-- O VINCULO QUE FAZ O APP FUNCIONAR:
-- o endereco e' da SECAO; o produto chega ate' la' pela CATEGORIA do ERP.
-- Remapear um corredor = mexer aqui, nao em 6.000 SKUs.
create table categoria_secao (
  id         uuid primary key default gen_random_uuid(),
  loja_id    uuid not null references lojas(id) on delete cascade,
  categoria  text not null,
  secao_id   uuid not null references secoes(id) on delete cascade,
  unique (loja_id, categoria)
);

create table listas (
  id         uuid primary key default gen_random_uuid(),
  cliente_id text not null,            -- id do dispositivo no piloto
  cliente_nome text,
  loja_id    uuid references lojas(id) on delete set null,
  status     text default 'aberta',    -- aberta | em_compra | fechada
  criada_em  timestamptz default now()
);

create table itens_lista (
  id         uuid primary key default gen_random_uuid(),
  lista_id   uuid not null references listas(id) on delete cascade,
  produto_id uuid references produtos(id) on delete set null,
  descricao  text not null,
  qtd        int default 1,
  preco_prev numeric(10,2) default 0,
  status     text default 'pendente'   -- pendente | pego | nao_encontrado
);

create table sessoes (
  id             uuid primary key default gen_random_uuid(),
  lista_id       uuid references listas(id) on delete set null,
  loja_id        uuid not null references lojas(id) on delete cascade,
  cliente_id     text not null,
  inicio         timestamptz default now(),
  fim            timestamptz,
  itens_total    int default 0,
  itens_pegos    int default 0,
  valor_previsto numeric(10,2) default 0,
  valor_real     numeric(10,2) default 0
);

create table eventos (
  id         uuid primary key default gen_random_uuid(),
  sessao_id  uuid references sessoes(id) on delete cascade,
  loja_id    uuid references lojas(id) on delete cascade,
  tipo       text not null,            -- pego | nao_encontrado | sugestao_recusada
  produto_id uuid references produtos(id) on delete set null,
  descricao  text,
  criado_em  timestamptz default now()
);

create index on corredores (loja_id, ordem);
create index on secoes (corredor_id, ordem);
create index on produtos (loja_id, categoria);
create index on itens_lista (lista_id);
create index on sessoes (loja_id, fim);
create index on eventos (loja_id, criado_em desc);

-- ------------------------------------------------------------
-- Endereco em 3 niveis, pronto para o app: corredor / secao / prateleira
-- ------------------------------------------------------------
create or replace view v_produto_endereco as
select
  p.id            as produto_id,
  p.loja_id,
  p.descricao,
  p.categoria,
  p.preco,
  p.estoque,
  c.codigo        as corredor,
  c.nome          as corredor_nome,
  c.ordem         as corredor_ordem,
  c.perimetro,
  s.id            as secao_id,
  s.nome          as secao,
  s.prateleira,
  s.lado,
  s.ordem         as secao_ordem
from produtos p
left join categoria_secao cs on cs.loja_id = p.loja_id and cs.categoria = p.categoria
left join secoes s           on s.id = cs.secao_id
left join corredores c       on c.id = s.corredor_id;

-- ------------------------------------------------------------
-- Previsao de chegada aos caixas: a partir das sessoes ativas.
-- Regressao simples: itens restantes x tempo medio por item.
-- ------------------------------------------------------------
create or replace view v_previsao_caixa as
with ativas as (
  select
    s.id,
    s.itens_total,
    s.itens_pegos,
    greatest(s.itens_total - s.itens_pegos, 0) as restantes,
    extract(epoch from (now() - s.inicio))/60  as min_decorridos
  from sessoes s
  where s.fim is null and s.inicio > now() - interval '3 hours'
)
select
  date_trunc('hour', now())
    + (floor(extract(minute from now())/15) * interval '15 min')
    + (bucket * interval '15 min')                     as janela,
  bucket,
  count(*)                                             as pessoas
from (
  select
    floor(
      least(
        greatest((restantes * 1.6) / 15.0, 0),   -- ~1,6 min por item restante
        7
      )
    )::int as bucket
  from ativas
) b
group by bucket
order by bucket;

-- ------------------------------------------------------------
-- RLS — piloto: catalogo publico para leitura, escrita livre nas
-- tabelas de uso do cliente. Antes de producao, trocar por
-- politicas por usuario autenticado.
-- ------------------------------------------------------------
alter table lojas           enable row level security;
alter table corredores      enable row level security;
alter table secoes          enable row level security;
alter table produtos        enable row level security;
alter table categoria_secao enable row level security;
alter table listas          enable row level security;
alter table itens_lista     enable row level security;
alter table sessoes         enable row level security;
alter table eventos         enable row level security;

create policy leitura_publica on lojas           for select using (true);
create policy leitura_publica on corredores      for select using (true);
create policy leitura_publica on secoes          for select using (true);
create policy leitura_publica on produtos        for select using (true);
create policy leitura_publica on categoria_secao for select using (true);

create policy uso_piloto on listas      for all using (true) with check (true);
create policy uso_piloto on itens_lista for all using (true) with check (true);
create policy uso_piloto on sessoes     for all using (true) with check (true);
create policy uso_piloto on eventos     for all using (true) with check (true);
