import { HashRouter, Route, Routes } from 'react-router-dom'
import Descoberta from './pages/Descoberta'
import Lista from './pages/Lista'
import Rota from './pages/Rota'
import Fim from './pages/Fim'
import PainelLoja from './pages/PainelLoja'

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Descoberta />} />
        <Route path="/lista" element={<Lista />} />
        <Route path="/rota" element={<Rota />} />
        <Route path="/fim" element={<Fim />} />
        <Route path="/loja" element={<PainelLoja />} />
        <Route path="*" element={<Descoberta />} />
      </Routes>
    </HashRouter>
  )
}
