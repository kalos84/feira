import { useEffect, useState } from 'react'
import { HashRouter, Route, Routes } from 'react-router-dom'
import Descoberta from './pages/Descoberta'
import Lista from './pages/Lista'
import Rota from './pages/Rota'
import Fim from './pages/Fim'
import PainelLoja from './pages/PainelLoja'
import Login from './pages/Login'
import { aoMudarSessao, exigeLogin, sessaoAtual, type Usuario } from './lib/auth'

export default function App() {
  const [usuario, setUsuario] = useState<Usuario>(null)
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    sessaoAtual().then((u) => { setUsuario(u); setCarregando(false) })
    return aoMudarSessao(setUsuario)
  }, [])

  if (carregando) {
    return <div className="app"><div className="corpo"><p className="vazio-estado">Carregando…</p></div></div>
  }

  if (exigeLogin && !usuario) return <Login />

  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Descoberta />} />
        <Route path="/lista" element={<Lista />} />
        <Route path="/rota" element={<Rota />} />
        <Route path="/fim" element={<Fim />} />
        <Route path="/loja" element={<PainelLoja />} />
        <Route path="*" element={<Descoberta />} />
      </Routes>
    </HashRouter>
  )
}
