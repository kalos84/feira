import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { listarLojas, modo } from '../lib/dados'
import { exigeLogin, sair } from '../lib/auth'
import { moeda } from '../lib/cliente'
import type { Loja } from '../lib/tipos'

function distanciaKm(a: { lat: number | null; lng: number | null }, b: GeolocationCoordinates) {
  if (a.lat == null || a.lng == null) return null
  const R = 6371, rad = (x: number) => (x * Math.PI) / 180
  const dLat = rad(a.lat - b.latitude), dLng = rad(a.lng - b.longitude)
  const s = Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(b.latitude)) * Math.cos(rad(a.lat)) * Math.sin(dLng / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s))
}

export default function Descoberta() {
  const nav = useNavigate()
  const [lojas, setLojas] = useState<Loja[]>([])
  const [busca, setBusca] = useState('')
  const [coords, setCoords] = useState<GeolocationCoordinates | null>(null)
  const [geoEstado, setGeoEstado] = useState<'pedindo' | 'ok' | 'negado' | 'indisponivel'>('pedindo')
  const [carregando, setCarregando] = useState(true)
  const [erro, setErro] = useState<string | null>(null)

  const preferida = (() => { try { return localStorage.getItem('feira.loja') } catch { return null } })()

  useEffect(() => {
    listarLojas().then(setLojas).catch((e) => setErro(String(e.message ?? e)))
      .finally(() => setCarregando(false))
    if (!navigator.geolocation) { setGeoEstado('indisponivel'); return }
    navigator.geolocation.getCurrentPosition(
      (p) => { setCoords(p.coords); setGeoEstado('ok') },
      () => setGeoEstado('negado'),
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 },
    )
  }, [])

  const ordenadas = useMemo(() => {
    const filtro = busca.trim().toLowerCase()
    return lojas
      .map((l) => ({ l, km: coords ? distanciaKm(l, coords) : null }))
      .filter(({ l }) => !filtro || l.nome.toLowerCase().includes(filtro) ||
                          (l.endereco ?? '').toLowerCase().includes(filtro))
      .sort((a, b) => {
        if (a.l.id === preferida) return -1
        if (b.l.id === preferida) return 1
        if (a.km != null && b.km != null) return a.km - b.km
        return a.l.nome.localeCompare(b.l.nome)
      })
  }, [lojas, busca, coords, preferida])

  function escolher(l: Loja) {
    try { localStorage.setItem('feira.loja', l.id) } catch { /* ignore */ }
    nav('/lista')
  }

  return (
    <div className="app">
      <header className="topo-app">
        <div className="linha1">
          <div>
            <h1>Onde vamos hoje?</h1>
            <p>
              {geoEstado === 'ok' ? 'Mercados perto de você'
                : geoEstado === 'pedindo' ? 'Procurando sua localização…'
                : geoEstado === 'negado' ? 'Sem localização — busque pelo nome'
                : 'Mercados cadastrados'}
              {modo === 'demo' && <> · <span className="selo demo">demo</span></>}
            </p>
          </div>
          {exigeLogin && (
            <button className="link" onClick={() => sair()}>sair</button>
          )}
        </div>
      </header>

      <div className="corpo">
        <div className="busca">
          <svg width="15" height="15" viewBox="0 0 16 16" aria-hidden="true">
            <circle cx="7" cy="7" r="5" fill="none" stroke="var(--tinta-3)" strokeWidth="1.8" />
            <path d="M11 11 L14.5 14.5" stroke="var(--tinta-3)" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          <input value={busca} onChange={(e) => setBusca(e.target.value)}
                 placeholder="Buscar mercado pelo nome" aria-label="Buscar mercado pelo nome" />
        </div>

        {carregando && <p className="vazio-estado">Carregando mercados…</p>}
        {erro && <div className="cartao alerta"><h3>Não consegui carregar os mercados</h3><p>{erro}</p></div>}

        {ordenadas.map(({ l, km }) => (
          <button key={l.id} className="mercado" aria-pressed={l.id === preferida}
                  onClick={() => escolher(l)}>
            <span className="dist">{km != null ? `${km.toFixed(1)} km` : '—'}</span>
            <span className="corpo2">
              <span className="nome">{l.nome}{l.id === preferida && <> <span className="selo">sua loja</span></>}</span>
              <span className="linha2">
                <span className="nota-exp" style={{ color: l.nota >= 4.5 ? 'var(--verde)' : 'var(--caixote)' }}>
                  ★ {l.nota.toFixed(1)}
                </span>
                <span>achabilidade <b>{l.achabilidade}%</b></span>
                <span>{l.caixas} caixas</span>
              </span>
            </span>
          </button>
        ))}

        {!carregando && ordenadas.length === 0 && (
          <p className="vazio-estado">Nenhum mercado encontrado com esse nome.</p>
        )}

        <Media />

        <p className="aviso">
          A nota é da experiência — achabilidade, frescor, fila e limpeza. O FEIRA não compara o preço
          de uma loja com o da outra: compara você com você mesmo.
        </p>
      </div>
    </div>
  )
}

function Media() {
  const [media, setMedia] = useState<number | null>(null)
  useEffect(() => {
    try {
      const h = JSON.parse(localStorage.getItem('feira.historico') || '[]') as number[]
      if (h.length) setMedia(h.reduce((a, b) => a + b, 0) / h.length)
    } catch { /* ignore */ }
  }, [])
  if (media == null) return null
  return (
    <div className="historico">
      <div className="cima">
        <span style={{ fontSize: 13, color: 'var(--tinta-2)' }}>Sua média por feira</span>
        <span className="val">{moeda(media)}</span>
      </div>
      <p>Calculada sobre as suas compras registradas aqui — nunca sobre a loja do vizinho.</p>
    </div>
  )
}
