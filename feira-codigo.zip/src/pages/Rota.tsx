import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Planta from '../components/Planta'
import { catalogo, corredores as lerCorredores, fecharSessao, itens as lerItens, listaAtual, marcar } from '../lib/dados'
import { moeda } from '../lib/cliente'
import type { Corredor, ItemLista, Produto, Sessao } from '../lib/tipos'

/** Ordena a lista pela sequência física da loja: corredor, depois posição na gôndola. */
function ordenar(itens: ItemLista[]): ItemLista[] {
  return [...itens].sort((a, b) => {
    const ca = a.produto?.corredor_ordem ?? 999, cb = b.produto?.corredor_ordem ?? 999
    if (ca !== cb) return ca - cb
    return (a.produto?.secao_ordem ?? 99) - (b.produto?.secao_ordem ?? 99)
  })
}

export default function Rota() {
  const nav = useNavigate()
  const [itens, setItens] = useState<ItemLista[]>([])
  const [corrs, setCorrs] = useState<Corredor[]>([])
  const [cat, setCat] = useState<Produto[]>([])
  const [listaId, setListaId] = useState<string | null>(null)
  const [vista, setVista] = useState<'mapa' | 'lista'>('mapa')
  const [carregando, setCarregando] = useState(true)

  const lojaId = (() => { try { return localStorage.getItem('feira.loja') } catch { return null } })()
  const sessao: Sessao | null = (() => {
    try { return JSON.parse(sessionStorage.getItem('feira.sessao') || 'null') } catch { return null }
  })()

  useEffect(() => {
    if (!lojaId) { nav('/'); return }
    ;(async () => {
      const c = await catalogo(lojaId)
      setCat(c)
      setCorrs(await lerCorredores(lojaId))
      const lid = await listaAtual(lojaId)
      setListaId(lid)
      setItens(await lerItens(lid, c))
      setCarregando(false)
    })()
  }, [lojaId])

  const ordenados = useMemo(() => ordenar(itens), [itens])
  const pendentes = ordenados.filter((i) => i.status === 'pendente')
  const atual = pendentes[0] ?? null
  const feitos = ordenados.filter((i) => i.status !== 'pendente')

  const corrFeitos = [...new Set(feitos.map((i) => i.produto?.corredor).filter(Boolean))] as string[]
  const corrFalta = [...new Set(pendentes.slice(1).map((i) => i.produto?.corredor).filter(Boolean))] as string[]

  async function resolver(item: ItemLista, status: 'pego' | 'nao_encontrado') {
    await marcar(item.id, status, {
      sessaoId: sessao?.id ?? null,
      lojaId: lojaId!,
      descricao: `${item.descricao}${item.produto?.corredor ? ` · ${item.produto.corredor} · ${item.produto.secao}` : ''}`,
    })
    if (listaId) setItens(await lerItens(listaId, cat))
  }

  async function terminar() {
    const pegos = ordenados.filter((i) => i.status === 'pego')
    const valor = pegos.reduce((s, i) => s + i.preco_prev * i.qtd, 0)
    if (sessao) await fecharSessao(sessao.id, pegos.length, valor)
    try {
      const h = JSON.parse(localStorage.getItem('feira.historico') || '[]') as number[]
      h.push(valor)
      localStorage.setItem('feira.historico', JSON.stringify(h.slice(-12)))
      sessionStorage.setItem('feira.resumo', JSON.stringify({
        inicio: sessao?.inicio ?? new Date().toISOString(),
        itensTotal: ordenados.length, pegos: pegos.length,
        naoEncontrados: ordenados.filter((i) => i.status === 'nao_encontrado').length,
        previsto: ordenados.reduce((s, i) => s + i.preco_prev * i.qtd, 0), real: valor,
      }))
    } catch { /* ignore */ }
    nav('/fim')
  }

  if (carregando) return <div className="app"><div className="corpo"><p className="vazio-estado">Montando sua rota…</p></div></div>

  const totalItens = ordenados.length
  const prontos = feitos.length

  return (
    <div className="app">
      <header className="topo-app">
        <div className="linha1">
          <div>
            <h1>{atual ? 'Siga a rota' : 'Tudo resolvido'}</h1>
            <p>{prontos} de {totalItens} itens</p>
          </div>
          <button className="link" onClick={terminar}>encerrar</button>
        </div>
      </header>

      <div className="corpo">
        <div className="andamento">
          <div className="trilha"><i style={{ width: `${totalItens ? (prontos / totalItens) * 100 : 0}%` }} /></div>
          <span>{prontos}/{totalItens}</span>
        </div>

        {atual && (
          <div className="endereco">
            <div className="cod">
              {atual.produto?.corredor
                ? `${atual.produto.corredor} · ${atual.produto.secao} · prat. ${atual.produto.prateleira}`
                : 'endereço não mapeado'}
            </div>
            <p className="prod">{atual.descricao}{atual.qtd > 1 && ` · ${atual.qtd}un`}</p>
            <p className="dica">
              {atual.produto?.prateleira === 3 ? 'Na altura dos olhos. ' : ''}
              {atual.produto?.lado ? `Lado ${atual.produto.lado} do corredor. ` : ''}
              {atual.produto?.corredor_nome ?? ''}
              {atual.produto && atual.produto.estoque <= 0 && ' · o estoque acusa zero — pode não estar lá.'}
            </p>
            {atual.produto?.prateleira != null && (
              <div className="niveis">
                {[5, 4, 3, 2, 1].map((n) => (
                  <div key={n} className={'nivel' + (n === atual.produto!.prateleira ? ' aqui' : '')}>
                    <span>P{n}</span><span className="barra-n" />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="abas">
          <button aria-pressed={vista === 'mapa'} onClick={() => setVista('mapa')}>Mapa</button>
          <button aria-pressed={vista === 'lista'} onClick={() => setVista('lista')}>Lista</button>
        </div>

        {vista === 'mapa' ? (
          <>
            <Planta corredores={corrs} rota={corrFalta}
                    atual={atual?.produto?.corredor ?? null} feitos={corrFeitos} />
            <div className="legenda">
              <span><i style={{ background: 'var(--verde)' }} /> já percorrido</span>
              <span><i style={{ background: 'var(--lona)' }} /> falta</span>
              <span><i style={{ background: 'var(--caixote)' }} /> você está aqui</span>
            </div>
          </>
        ) : (
          <div>
            {ordenados.map((i) => (
              <div className={'item' + (i.status !== 'pendente' ? ' feito' : '')} key={i.id}>
                <button className={'tique' + (i.status === 'pego' ? ' on' : i.status === 'nao_encontrado' ? ' falhou' : '')}
                        onClick={() => resolver(i, i.status === 'pendente' ? 'pego' : 'pego')}
                        aria-label={`Marcar ${i.descricao} como pego`}>
                  {i.status === 'nao_encontrado' ? '!' : ''}
                </button>
                <span className="txt">
                  <span className="nome">{i.descricao}</span>
                  <span className="meta">
                    {i.produto?.corredor ? `${i.produto.corredor} · ${i.produto.secao} · prat. ${i.produto.prateleira}` : '—'}
                  </span>
                </span>
                <span className="val">{moeda(i.preco_prev * i.qtd)}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <footer className="rodape-app">
        {atual ? (
          <div className="dupla">
            <button className="btn" onClick={() => resolver(atual, 'pego')}>Peguei</button>
            <button className="btn vazio" onClick={() => resolver(atual, 'nao_encontrado')}>Não encontrei</button>
          </div>
        ) : (
          <button className="btn" onClick={terminar}>Ir para o caixa</button>
        )}
      </footer>
    </div>
  )
}
