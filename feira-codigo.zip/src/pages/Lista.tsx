import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { adicionar, abrirSessao, catalogo, itens as lerItens, listaAtual, listarLojas, modo, mudarQtd } from '../lib/dados'
import { moeda } from '../lib/cliente'
import type { ItemLista, Loja, Produto } from '../lib/tipos'

export default function Lista() {
  const nav = useNavigate()
  const [loja, setLoja] = useState<Loja | null>(null)
  const [cat, setCat] = useState<Produto[]>([])
  const [listaId, setListaId] = useState<string | null>(null)
  const [itens, setItens] = useState<ItemLista[]>([])
  const [busca, setBusca] = useState('')
  const [carregando, setCarregando] = useState(true)
  const [erro, setErro] = useState<string | null>(null)
  const campo = useRef<HTMLInputElement>(null)

  const lojaId = (() => { try { return localStorage.getItem('feira.loja') } catch { return null } })()

  useEffect(() => {
    if (!lojaId) { nav('/'); return }
    ;(async () => {
      try {
        const ls = await listarLojas()
        setLoja(ls.find((l) => l.id === lojaId) ?? ls[0] ?? null)
        const c = await catalogo(lojaId)
        setCat(c)
        const lid = await listaAtual(lojaId)
        setListaId(lid)
        setItens(await lerItens(lid, c))
      } catch (e: any) { setErro(String(e.message ?? e)) }
      finally { setCarregando(false) }
    })()
  }, [lojaId])

  async function recarregar(lid = listaId) {
    if (lid) setItens(await lerItens(lid, cat))
  }

  const sugestoes = useMemo(() => {
    const q = busca.trim().toLowerCase()
    if (q.length < 2) return []
    return cat.filter((p) => p.descricao.toLowerCase().includes(q)).slice(0, 8)
  }, [busca, cat])

  const total = itens.reduce((s, i) => s + i.preco_prev * i.qtd, 0)

  async function add(p: Produto) {
    if (!listaId) return
    await adicionar(listaId, p)
    setBusca('')
    campo.current?.focus()
    await recarregar()
  }

  async function iniciar() {
    if (!listaId || !loja) return
    const s = await abrirSessao(listaId, loja.id, itens.reduce((n, i) => n + i.qtd, 0), total)
    try { sessionStorage.setItem('feira.sessao', JSON.stringify(s)) } catch { /* ignore */ }
    nav('/rota')
  }

  return (
    <div className="app">
      <header className="topo-app">
        <div className="linha1">
          <div>
            <h1>Nossa feira</h1>
            <p>
              {loja?.nome ?? '—'} · {itens.length} {itens.length === 1 ? 'item' : 'itens'}
              {modo === 'demo' && <> · <span className="selo demo">demo</span></>}
            </p>
          </div>
          <button className="link" onClick={() => nav('/')}>trocar loja</button>
        </div>
      </header>

      <div className="corpo">
        <div className="busca">
          <svg width="15" height="15" viewBox="0 0 16 16" aria-hidden="true">
            <circle cx="7" cy="7" r="5" fill="none" stroke="var(--tinta-3)" strokeWidth="1.8" />
            <path d="M11 11 L14.5 14.5" stroke="var(--tinta-3)" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          <input ref={campo} value={busca} onChange={(e) => setBusca(e.target.value)}
                 placeholder="O que falta em casa?" aria-label="Buscar produto" />
        </div>

        {sugestoes.length > 0 && (
          <div className="sugestoes" role="listbox">
            {sugestoes.map((p) => (
              <button key={p.id} onClick={() => add(p)}>
                <span>
                  {p.descricao}
                  <br />
                  <span className="end">
                    {p.corredor ? `${p.corredor} · ${p.secao} · prat. ${p.prateleira}` : 'sem endereço'}
                  </span>
                </span>
                <span className="mono">{moeda(p.preco)}</span>
              </button>
            ))}
          </div>
        )}

        {carregando && <p className="vazio-estado">Carregando o catálogo da loja…</p>}
        {erro && <div className="cartao alerta"><h3>Erro</h3><p>{erro}</p></div>}

        {!carregando && itens.length === 0 && (
          <p className="vazio-estado">
            Sua lista está vazia.<br />Busque um produto acima para começar.
          </p>
        )}

        {itens.map((i) => (
          <div className="item" key={i.id}>
            <span className="txt">
              <span className="nome">{i.descricao}</span>
              <span className="meta">
                {i.produto?.corredor
                  ? `${i.produto.corredor} · ${i.produto.secao} · prateleira ${i.produto.prateleira}`
                  : 'endereço ainda não mapeado'}
                {i.produto && i.produto.estoque <= 0 && ' · sem estoque no sistema'}
              </span>
              <span className="qtd">
                <button onClick={async () => { await mudarQtd(i.id, i.qtd - 1); recarregar() }}
                        aria-label={`Diminuir ${i.descricao}`}>−</button>
                <span className="mono">{i.qtd}</span>
                <button onClick={async () => { await mudarQtd(i.id, i.qtd + 1); recarregar() }}
                        aria-label={`Aumentar ${i.descricao}`}>+</button>
              </span>
            </span>
            <span className="val">{moeda(i.preco_prev * i.qtd)}</span>
          </div>
        ))}
      </div>

      <footer className="rodape-app">
        <div className="total">
          <span className="rot">Total previsto</span>
          <span className="num">{moeda(total)}</span>
        </div>
        <button className="btn" disabled={itens.length === 0} onClick={iniciar}>
          Iniciar compras
        </button>
      </footer>
    </div>
  )
}
