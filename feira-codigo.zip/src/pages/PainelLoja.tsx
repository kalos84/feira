import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { listarLojas, modo, rupturas, sessoesAtivas, sessoesFechadas } from '../lib/dados'
import { minutosEntre, moeda } from '../lib/cliente'
import type { Evento, Loja, Sessao } from '../lib/tipos'

const MIN_POR_ITEM = 1.6   // ritmo médio de compra observado; recalibrar com dado do piloto

/** Distribui as sessões ativas em janelas de 15 min conforme o que falta da lista. */
function previsao(ativas: Sessao[]) {
  const janelas = Array.from({ length: 8 }, (_, i) => ({ i, pessoas: 0 }))
  for (const s of ativas) {
    const restantes = Math.max(0, s.itens_total - s.itens_pegos)
    const minutos = restantes * MIN_POR_ITEM
    const idx = Math.min(7, Math.floor(minutos / 15))
    janelas[idx].pessoas++
  }
  return janelas
}

function rotuloJanela(i: number) {
  const d = new Date(Date.now() + (i + 1) * 15 * 60000)
  return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
}

export default function PainelLoja() {
  const [loja, setLoja] = useState<Loja | null>(null)
  const [ativas, setAtivas] = useState<Sessao[]>([])
  const [fechadas, setFechadas] = useState<Sessao[]>([])
  const [faltas, setFaltas] = useState<Evento[]>([])
  const [agora, setAgora] = useState(new Date())

  const lojaId = (() => { try { return localStorage.getItem('feira.loja') } catch { return null } })()

  async function puxar(id: string) {
    const [a, f, r] = await Promise.all([sessoesAtivas(id), sessoesFechadas(id), rupturas(id)])
    setAtivas(a); setFechadas(f); setFaltas(r); setAgora(new Date())
  }

  useEffect(() => {
    ;(async () => {
      const ls = await listarLojas()
      const l = ls.find((x) => x.id === lojaId) ?? ls[0]
      if (!l) return
      setLoja(l)
      await puxar(l.id)
    })()
  }, [lojaId])

  useEffect(() => {
    if (!loja) return
    const t = setInterval(() => puxar(loja.id), 10000)
    return () => clearInterval(t)
  }, [loja])

  const j = previsao(ativas)
  const maior = Math.max(1, ...j.map((x) => x.pessoas))
  const capacidade = Math.max(1, (loja?.caixas ?? 4) * 4)          // ~4 clientes por caixa a cada 15 min
  const estouro = j.findIndex((x) => x.pessoas > capacidade)

  const temposFechados = fechadas.filter((s) => s.fim).map((s) => minutosEntre(s.inicio, s.fim))
  const tempoMedio = temposFechados.length
    ? Math.round(temposFechados.reduce((a, b) => a + b, 0) / temposFechados.length) : null
  const itensPrevistos = fechadas.reduce((n, s) => n + s.itens_total, 0)
  const itensPegos = fechadas.reduce((n, s) => n + s.itens_pegos, 0)
  const achabilidade = itensPrevistos ? Math.round((itensPegos / itensPrevistos) * 100) : null
  const ticket = fechadas.length
    ? fechadas.reduce((n, s) => n + Number(s.valor_real), 0) / fechadas.length : null

  return (
    <div className="painel-loja">
      <div className="cab">
        <div>
          <h1>PULSO · {loja?.nome ?? 'painel da loja'}</h1>
          <p>
            Cada sessão ativa carrega uma cesta de tamanho conhecido. A soma delas é a curva de
            chegada aos caixas — não uma média histórica.
            {modo === 'demo' && <> <span className="selo demo">demo local</span></>}
          </p>
        </div>
        <span className="viva">
          <span className="pisca" /> {ativas.length} {ativas.length === 1 ? 'sessão ativa' : 'sessões ativas'} ·{' '}
          {agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>

      <div className="grade">
        <div>
          <div className="painel">
            <span className="eyebrow">Chegada prevista aos caixas · próximos 120 min</span>
            {ativas.length === 0 ? (
              <p className="vazio-estado" style={{ padding: '38px 12px' }}>
                Sem cliente em compra agora — a curva aparece quando a primeira lista começar.
              </p>
            ) : (<>
            <div className="grafico">
              {j.map((x) => (
                <div key={x.i} className={'col' + (x.pessoas > capacidade ? ' pico' : '')}>
                  <span className="v">{x.pessoas}</span>
                  <span className="b" style={{ height: `${(x.pessoas / maior) * 100}%` }} />
                </div>
              ))}
            </div>
            <div className="eixo">{j.map((x) => <span key={x.i}>{rotuloJanela(x.i)}</span>)}</div>
            </>)}
            <div className="kpi" style={{ paddingTop: 12 }}>
              <span className="rot">Capacidade com {loja?.caixas ?? 0} caixas, por janela de 15 min</span>
              <span className="num">{capacidade}</span>
            </div>

            <div className="acao">
              <span className="eyebrow">Recomendação operacional</span>
              <p>
                {ativas.length === 0
                  ? 'Nenhum cliente em compra agora.'
                  : estouro >= 0
                    ? `Abra mais um caixa em ${(estouro + 1) * 15} minutos.`
                    : 'Fluxo dentro da capacidade atual.'}
              </p>
            </div>
            <p className="aviso">
              Ritmo estimado em {MIN_POR_ITEM.toLocaleString('pt-BR')} min por item restante. É o parâmetro a recalibrar com o dado
              real do piloto — está aqui explícito de propósito.
            </p>
          </div>

          <div className="painel">
            <span className="eyebrow">Sessões em andamento</span>
            {ativas.length === 0 && <p className="vazio-estado">Ninguém comprando agora.</p>}
            {ativas.map((s) => (
              <div className="ruptura" key={s.id}>
                <span>
                  {s.itens_pegos} de {s.itens_total} itens · previsto {moeda(Number(s.valor_previsto))}
                </span>
                <span className="quando">há {minutosEntre(s.inicio)} min</span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="painel">
            <span className="eyebrow">Indicadores</span>
            <div className="kpi">
              <span className="rot">Tempo médio de compra</span>
              <span className="num">{tempoMedio != null ? `${tempoMedio} min` : '—'}</span>
            </div>
            <div className="kpi">
              <span className="rot">Achabilidade<br />
                <span style={{ fontSize: 11.5, color: 'var(--tinta-3)' }}>itens da lista efetivamente encontrados</span>
              </span>
              <span className="num">{achabilidade != null ? `${achabilidade}%` : '—'}</span>
            </div>
            <div className="kpi">
              <span className="rot">Ticket médio · usuário FEIRA</span>
              <span className="num">{ticket != null ? moeda(ticket) : '—'}</span>
            </div>
            <div className="kpi">
              <span className="rot">Compras concluídas</span>
              <span className="num">{fechadas.length}</span>
            </div>
          </div>

          <div className="painel">
            <span className="eyebrow">Rupturas reportadas pelos clientes</span>
            {faltas.length === 0 && <p className="vazio-estado">Nenhuma ruptura reportada.</p>}
            {faltas.map((e) => (
              <div className="ruptura" key={e.id}>
                <span>{e.descricao}</span>
                <span className="quando">
                  {new Date(e.criado_em).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}
            <p className="aviso">
              Cada linha é um cliente que estava na frente da gôndola e não achou. Se o estoque acusa saldo,
              não é falta de compra: é endereço errado ou reposição atrasada.
            </p>
          </div>

          <p style={{ fontSize: 13.5 }}>
            <Link to="/" style={{ color: 'var(--lona)' }}>← voltar ao app do cliente</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
