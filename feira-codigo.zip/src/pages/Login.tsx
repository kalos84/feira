import { useState } from 'react'
import { entrar } from '../lib/auth'

export default function Login() {
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [erro, setErro] = useState<string | null>(null)
  const [indo, setIndo] = useState(false)

  async function enviar(e: React.FormEvent) {
    e.preventDefault()
    setIndo(true); setErro(null)
    const r = await entrar(email, senha)
    setIndo(false)
    if (r.erro) setErro(r.erro)
  }

  return (
    <div className="app">
      <div className="corpo" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', marginBottom: 26 }}>
          <svg width="52" height="52" viewBox="0 0 40 40" aria-hidden="true" style={{ marginBottom: 10 }}>
            <path d="M4 14 L12 4 L28 4 L36 14 Z" fill="var(--lona)" />
            <path d="M4 14 L36 14 L36 17 L4 17 Z" fill="var(--lona-forte)" />
            <rect x="9" y="21" width="22" height="14" rx="2" fill="none" stroke="var(--caixote)" strokeWidth="2.5" />
            <path d="M9 27 H31" stroke="var(--caixote)" strokeWidth="2.5" />
          </svg>
          <h1 style={{ fontSize: 30, fontWeight: 800, letterSpacing: '-.02em' }}>FEIRA</h1>
          <p style={{ margin: '4px 0 0', fontSize: 13.5, color: 'var(--tinta-3)' }}>
            Piloto fechado · acesso por convite
          </p>
        </div>

        <form onSubmit={enviar}>
          <label className="eyebrow" htmlFor="email">E-mail</label>
          <div className="busca" style={{ marginBottom: 12 }}>
            <input id="email" type="email" value={email} autoComplete="username"
                   onChange={(e) => setEmail(e.target.value)} placeholder="seu acesso" required />
          </div>

          <label className="eyebrow" htmlFor="senha">Senha</label>
          <div className="busca" style={{ marginBottom: 16 }}>
            <input id="senha" type="password" value={senha} autoComplete="current-password"
                   onChange={(e) => setSenha(e.target.value)} placeholder="senha do piloto" required />
          </div>

          {erro && (
            <div className="cartao alerta" style={{ marginBottom: 14 }}>
              <p>{erro}</p>
            </div>
          )}

          <button className="btn" type="submit" disabled={indo}>
            {indo ? 'Entrando…' : 'Entrar'}
          </button>
        </form>

        <p className="aviso" style={{ marginTop: 22 }}>
          Não há cadastro aberto. O acesso é criado por quem administra o piloto — se você precisa de
          um, fale com quem te passou este endereço.
        </p>
      </div>
    </div>
  )
}
