import { useNavigate } from 'react-router-dom'
import { minutosEntre, moeda } from '../lib/cliente'

type Resumo = {
  inicio: string; itensTotal: number; pegos: number; naoEncontrados: number
  previsto: number; real: number
}

export default function Fim() {
  const nav = useNavigate()
  const r: Resumo | null = (() => {
    try { return JSON.parse(sessionStorage.getItem('feira.resumo') || 'null') } catch { return null }
  })()

  if (!r) {
    return (
      <div className="app">
        <div className="corpo"><p className="vazio-estado">Nenhuma compra registrada nesta sessão.</p></div>
        <footer className="rodape-app"><button className="btn" onClick={() => nav('/')}>Começar uma feira</button></footer>
      </div>
    )
  }

  const min = Math.max(1, minutosEntre(r.inicio))
  const media = (() => {
    try {
      const h = JSON.parse(localStorage.getItem('feira.historico') || '[]') as number[]
      return h.length > 1 ? h.slice(0, -1).reduce((a, b) => a + b, 0) / (h.length - 1) : null
    } catch { return null }
  })()

  return (
    <div className="app">
      <header className="topo-app">
        <div className="linha1">
          <div>
            <h1>Feira feita</h1>
            <p>{r.pegos} de {r.itensTotal} itens</p>
          </div>
        </div>
      </header>

      <div className="corpo">
        <p className="eyebrow">Tempo de compra</p>
        <p className="fim-num">{min} min</p>

        <div style={{ marginTop: 22 }}>
          <div className="linha-dados"><span>Previsto na lista</span><b>{moeda(r.previsto)}</b></div>
          <div className="linha-dados"><span>Gasto real</span><b>{moeda(r.real)}</b></div>
          {media != null && (
            <div className="linha-dados"><span>Sua média anterior</span><b>{moeda(media)}</b></div>
          )}
          <div className="linha-dados"><span>Itens não encontrados</span><b>{r.naoEncontrados}</b></div>
        </div>

        {r.naoEncontrados > 0 && (
          <div className="cartao alerta" style={{ marginTop: 18 }}>
            <h3>{r.naoEncontrados === 1 ? 'Um item foi reportado' : `${r.naoEncontrados} itens foram reportados`}</h3>
            <p>A loja recebeu o aviso com o endereço e o horário. É assim que o mapa se corrige.</p>
          </div>
        )}

        <div className="cartao ok" style={{ marginTop: r.naoEncontrados > 0 ? 0 : 18 }}>
          <h3>A próxima lista já começa pronta</h3>
          <p>Os intervalos de recompra de cada item são aprendidos a partir desta feira.</p>
        </div>
      </div>

      <footer className="rodape-app">
        <div className="dupla">
          <button className="btn vazio" onClick={() => nav('/')}>Nova feira</button>
          <button className="btn" onClick={() => nav('/loja')}>Ver o painel da loja</button>
        </div>
      </footer>
    </div>
  )
}
