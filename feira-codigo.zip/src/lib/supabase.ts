import { createClient, SupabaseClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

export const temBanco = Boolean(url && key)
export const sb: SupabaseClient | null = temBanco ? createClient(url!, key!) : null
