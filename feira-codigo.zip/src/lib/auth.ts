import { sb, temBanco } from './supabase'

export type Usuario = { id: string; email: string | null } | null

/** Sessão atual. No modo demo (sem banco) não há login: devolve um usuário fictício. */
export async function sessaoAtual(): Promise<Usuario> {
  if (!sb) return { id: 'demo', email: null }
  const { data } = await sb.auth.getSession()
  const u = data.session?.user
  return u ? { id: u.id, email: u.email ?? null } : null
}

export async function entrar(email: string, senha: string): Promise<{ erro: string | null }> {
  if (!sb) return { erro: null }
  const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password: senha })
  if (!error) return { erro: null }
  const m = error.message.toLowerCase()
  if (m.includes('invalid login credentials')) return { erro: 'E-mail ou senha não conferem.' }
  if (m.includes('email not confirmed')) return { erro: 'Este acesso ainda não foi confirmado.' }
  return { erro: error.message }
}

export async function sair(): Promise<void> {
  if (sb) await sb.auth.signOut()
  try { localStorage.removeItem('feira.loja') } catch { /* ignore */ }
}

/** Avisa quando a sessão muda (login, logout, token renovado). */
export function aoMudarSessao(cb: (u: Usuario) => void): () => void {
  if (!sb) return () => {}
  const { data } = sb.auth.onAuthStateChange((_e, s) => {
    cb(s?.user ? { id: s.user.id, email: s.user.email ?? null } : null)
  })
  return () => data.subscription.unsubscribe()
}

export const exigeLogin = temBanco
