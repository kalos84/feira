/**
 * Camada de dados única do FEIRA.
 *
 * Duas implementações por trás da mesma interface:
 *  - Supabase, quando VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY existem;
 *  - modo demo em localStorage, alimentado por src/data/seed.ts, quando não existem.
 *
 * O app não sabe qual está ativa.
 */
import { sb, temBanco } from './supabase'
import { clienteId } from './cliente'
import { seed } from '../data/seed'
import type { Corredor, Evento, ItemLista, Loja, Produto, Sessao } from './tipos'

export const modo = temBanco ? 'banco' : 'demo'

// ------------------------------------------------------------------
// MODO DEMO — os mesmos dados do seed.sql, em memória + localStorage
// ------------------------------------------------------------------
const LOJA_DEMO = '11111111-1111-1111-1111-111111111111'
const uid = () => 'x_' + Math.random().toString(36).slice(2, 10)

const lojasDemo: Loja[] = [
  { id: LOJA_DEMO, nome: seed.loja.nome, endereco: seed.loja.endereco, cidade: seed.loja.cidade,
    lat: seed.loja.lat, lng: seed.loja.lng, caixas: seed.loja.caixas,
    nota: seed.loja.nota, achabilidade: seed.loja.achabilidade },
  { id: 'demo-2', nome: 'Bella Vitta Supermercado', endereco: 'Quadra falsa 104 Sul', cidade: 'Palmas',
    lat: -10.2402, lng: -48.3350, caixas: 5, nota: 4.2, achabilidade: 81 },
  { id: 'demo-3', nome: 'Atacadão Palmas', endereco: 'Av. Teotônio Segurado', cidade: 'Palmas',
    lat: -10.2117, lng: -48.3399, caixas: 14, nota: 4.0, achabilidade: 76 },
]

const corredoresDemo: Corredor[] = seed.corredores.map((c) => ({
  id: c.codigo, codigo: c.codigo, nome: c.nome, perimetro: c.perimetro, ordem: c.ordem,
}))

const catalogoDemo: Produto[] = seed.produtos.map((p) => {
  const secao = seed.secoes.find((s) => (s.categorias as readonly string[]).includes(p.categoria))
  const corr = secao ? seed.corredores.find((c) => c.codigo === secao.corredor) : undefined
  return {
    id: 'p_' + p.descricao.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    descricao: p.descricao, categoria: p.categoria, preco: p.preco, estoque: p.estoque,
    corredor: corr?.codigo ?? null, corredor_nome: corr?.nome ?? null,
    corredor_ordem: corr?.ordem ?? null, perimetro: corr?.perimetro ?? null,
    secao: secao?.nome ?? null, secao_id: secao ? corr!.codigo + '::' + secao.nome : null,
    prateleira: secao?.prateleira ?? null, lado: secao?.lado ?? null, secao_ordem: secao?.ordem ?? null,
  }
})

type EstadoDemo = {
  listaId: string | null
  lojaId: string
  itens: ItemLista[]
  sessoes: Sessao[]
  eventos: Evento[]
}
const VAZIO: EstadoDemo = { listaId: null, lojaId: LOJA_DEMO, itens: [], sessoes: [], eventos: [] }
const CHAVE = 'feira.demo'

function ler(): EstadoDemo {
  try { return { ...VAZIO, ...JSON.parse(localStorage.getItem(CHAVE) || '{}') } }
  catch { return { ...VAZIO } }
}
function gravar(e: EstadoDemo) {
  try { localStorage.setItem(CHAVE, JSON.stringify(e)) } catch { /* modo privado */ }
}

// ------------------------------------------------------------------
// API
// ------------------------------------------------------------------

export async function listarLojas(): Promise<Loja[]> {
  if (!sb) return lojasDemo
  const { data, error } = await sb.from('lojas').select('*').eq('ativa', true).order('nome')
  if (error) throw error
  return (data ?? []) as Loja[]
}

export async function catalogo(lojaId: string): Promise<Produto[]> {
  if (!sb) return catalogoDemo
  const { data, error } = await sb
    .from('v_produto_endereco')
    .select('*')
    .eq('loja_id', lojaId)
    .order('descricao')
  if (error) throw error
  return (data ?? []).map((r: any) => ({ ...r, id: r.produto_id })) as Produto[]
}

export async function corredores(lojaId: string): Promise<Corredor[]> {
  if (!sb) return corredoresDemo
  const { data, error } = await sb.from('corredores').select('*').eq('loja_id', lojaId).order('ordem')
  if (error) throw error
  return (data ?? []) as Corredor[]
}

/** Lista aberta do cliente nesta loja; cria se não existir. */
export async function listaAtual(lojaId: string): Promise<string> {
  if (!sb) {
    const e = ler()
    if (!e.listaId || e.lojaId !== lojaId) {
      e.listaId = uid(); e.lojaId = lojaId; e.itens = []
      gravar(e)
    }
    return e.listaId
  }
  const cid = clienteId()
  const { data: achou } = await sb.from('listas').select('id')
    .eq('cliente_id', cid).eq('loja_id', lojaId).eq('status', 'aberta').limit(1)
  if (achou && achou.length) return achou[0].id
  const { data, error } = await sb.from('listas')
    .insert({ cliente_id: cid, loja_id: lojaId, status: 'aberta' }).select('id').single()
  if (error) throw error
  return data!.id
}

export async function itens(listaId: string, cat: Produto[]): Promise<ItemLista[]> {
  if (!sb) {
    return ler().itens.map((i) => ({ ...i, produto: cat.find((p) => p.id === i.produto_id) ?? null }))
  }
  const { data, error } = await sb.from('itens_lista').select('*').eq('lista_id', listaId).order('id')
  if (error) throw error
  return (data ?? []).map((i: any) => ({ ...i, produto: cat.find((p) => p.id === i.produto_id) ?? null }))
}

export async function adicionar(listaId: string, p: Produto, qtd = 1): Promise<void> {
  if (!sb) {
    const e = ler()
    const ja = e.itens.find((i) => i.produto_id === p.id)
    if (ja) ja.qtd += qtd
    else e.itens.push({ id: uid(), produto_id: p.id, descricao: p.descricao, qtd,
                        preco_prev: p.preco, status: 'pendente' })
    gravar(e); return
  }
  const { data: ja } = await sb.from('itens_lista').select('id,qtd')
    .eq('lista_id', listaId).eq('produto_id', p.id).limit(1)
  if (ja && ja.length) {
    await sb.from('itens_lista').update({ qtd: ja[0].qtd + qtd }).eq('id', ja[0].id)
  } else {
    await sb.from('itens_lista').insert({
      lista_id: listaId, produto_id: p.id, descricao: p.descricao, qtd, preco_prev: p.preco,
    })
  }
}

export async function mudarQtd(itemId: string, qtd: number): Promise<void> {
  if (!sb) {
    const e = ler()
    if (qtd <= 0) e.itens = e.itens.filter((i) => i.id !== itemId)
    else { const i = e.itens.find((x) => x.id === itemId); if (i) i.qtd = qtd }
    gravar(e); return
  }
  if (qtd <= 0) await sb.from('itens_lista').delete().eq('id', itemId)
  else await sb.from('itens_lista').update({ qtd }).eq('id', itemId)
}

export async function marcar(
  itemId: string, status: ItemLista['status'],
  ctx?: { sessaoId: string | null; lojaId: string; descricao: string },
): Promise<void> {
  if (!sb) {
    const e = ler()
    const i = e.itens.find((x) => x.id === itemId)
    if (i) i.status = status
    if (ctx && status !== 'pendente') {
      e.eventos.unshift({ id: uid(), tipo: status, descricao: ctx.descricao,
                          criado_em: new Date().toISOString() })
      const s = e.sessoes.find((x) => x.id === ctx.sessaoId)
      if (s) s.itens_pegos = e.itens.filter((x) => x.status !== 'pendente').length
    }
    gravar(e); return
  }
  await sb.from('itens_lista').update({ status }).eq('id', itemId)
  if (ctx && status !== 'pendente') {
    await sb.from('eventos').insert({
      sessao_id: ctx.sessaoId, loja_id: ctx.lojaId, tipo: status, descricao: ctx.descricao,
    })
    if (ctx.sessaoId) {
      const { count } = await sb.from('itens_lista')
        .select('id', { count: 'exact', head: true })
        .eq('lista_id', (await sb.from('sessoes').select('lista_id').eq('id', ctx.sessaoId).single()).data!.lista_id)
        .neq('status', 'pendente')
      await sb.from('sessoes').update({ itens_pegos: count ?? 0 }).eq('id', ctx.sessaoId)
    }
  }
}

export async function abrirSessao(
  listaId: string, lojaId: string, itensTotal: number, valorPrevisto: number,
): Promise<Sessao> {
  if (!sb) {
    const e = ler()
    const s: Sessao = { id: uid(), loja_id: lojaId, inicio: new Date().toISOString(), fim: null,
                        itens_total: itensTotal, itens_pegos: 0,
                        valor_previsto: valorPrevisto, valor_real: 0 }
    e.sessoes.unshift(s); gravar(e); return s
  }
  const { data, error } = await sb.from('sessoes').insert({
    lista_id: listaId, loja_id: lojaId, cliente_id: clienteId(),
    itens_total: itensTotal, valor_previsto: valorPrevisto,
  }).select('*').single()
  if (error) throw error
  return data as Sessao
}

export async function fecharSessao(
  sessaoId: string, itensPegos: number, valorReal: number,
): Promise<void> {
  if (!sb) {
    const e = ler()
    const s = e.sessoes.find((x) => x.id === sessaoId)
    if (s) { s.fim = new Date().toISOString(); s.itens_pegos = itensPegos; s.valor_real = valorReal }
    e.listaId = null; e.itens = []
    gravar(e); return
  }
  await sb.from('sessoes').update({
    fim: new Date().toISOString(), itens_pegos: itensPegos, valor_real: valorReal,
  }).eq('id', sessaoId)
}

export async function sessoesAtivas(lojaId: string): Promise<Sessao[]> {
  if (!sb) return ler().sessoes.filter((s) => !s.fim)
  const { data, error } = await sb.from('sessoes').select('*')
    .eq('loja_id', lojaId).is('fim', null)
    .gte('inicio', new Date(Date.now() - 3 * 3600_000).toISOString())
    .order('inicio', { ascending: false })
  if (error) throw error
  return (data ?? []) as Sessao[]
}

export async function sessoesFechadas(lojaId: string, limite = 20): Promise<Sessao[]> {
  if (!sb) return ler().sessoes.filter((s) => s.fim).slice(0, limite)
  const { data, error } = await sb.from('sessoes').select('*')
    .eq('loja_id', lojaId).not('fim', 'is', null)
    .order('fim', { ascending: false }).limit(limite)
  if (error) throw error
  return (data ?? []) as Sessao[]
}

export async function rupturas(lojaId: string, limite = 15): Promise<Evento[]> {
  if (!sb) return ler().eventos.filter((e) => e.tipo === 'nao_encontrado').slice(0, limite)
  const { data, error } = await sb.from('eventos').select('*')
    .eq('loja_id', lojaId).eq('tipo', 'nao_encontrado')
    .order('criado_em', { ascending: false }).limit(limite)
  if (error) throw error
  return (data ?? []) as Evento[]
}
