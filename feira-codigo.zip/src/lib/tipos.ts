export type Loja = {
  id: string; nome: string; endereco: string | null; cidade: string | null
  lat: number | null; lng: number | null; caixas: number; nota: number; achabilidade: number
}
export type Corredor = {
  id: string; codigo: string; nome: string; perimetro: boolean; ordem: number
}
export type Secao = {
  id: string; corredor_id: string; nome: string; prateleira: number; lado: string; ordem: number
}
export type Produto = {
  id: string; descricao: string; categoria: string; preco: number; estoque: number
  corredor: string | null; corredor_nome: string | null; corredor_ordem: number | null
  perimetro: boolean | null; secao: string | null; secao_id: string | null
  prateleira: number | null; lado: string | null; secao_ordem: number | null
}
export type ItemLista = {
  id: string; produto_id: string | null; descricao: string; qtd: number
  preco_prev: number; status: 'pendente' | 'pego' | 'nao_encontrado'
  produto?: Produto | null
}
export type Sessao = {
  id: string; loja_id: string; inicio: string; fim: string | null
  itens_total: number; itens_pegos: number
  valor_previsto: number; valor_real: number
}
export type Evento = {
  id: string; tipo: string; descricao: string | null; criado_em: string
}
