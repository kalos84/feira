const CHAVE = 'feira.cliente'

export function clienteId(): string {
  try {
    let id = localStorage.getItem(CHAVE)
    if (!id) {
      id = 'c_' + Math.random().toString(36).slice(2) + Date.now().toString(36)
      localStorage.setItem(CHAVE, id)
    }
    return id
  } catch {
    return 'c_anonimo'
  }
}

export function moeda(v: number): string {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}

export function minutosEntre(a: string, b?: string | null): number {
  const ini = new Date(a).getTime()
  const fim = b ? new Date(b).getTime() : Date.now()
  return Math.max(0, Math.round((fim - ini) / 60000))
}
