import { useEffect, useRef } from 'react'

type Opcoes = {
  aoArrastarEsquerda: () => void   // dedo da direita para a esquerda → avança
  aoArrastarDireita: () => void    // da esquerda para a direita → volta
  ativo?: boolean
}

const DISTANCIA_MINIMA = 60   // px percorridos na horizontal
const TOLERANCIA_VERTICAL = 1.4 // o movimento tem de ser mais horizontal que vertical
const TEMPO_MAXIMO = 800      // ms — um arrasto lento é rolagem, não gesto

/** Ignora o gesto quando ele começa em algo que o próprio elemento usa. */
function ehZonaProibida(alvo: EventTarget | null): boolean {
  const el = alvo as HTMLElement | null
  if (!el || !el.closest) return false
  return Boolean(
    el.closest('input, textarea, select, .sugestoes, .menu-folha, .grafico, .planta'),
  )
}

export function useSwipe({ aoArrastarEsquerda, aoArrastarDireita, ativo = true }: Opcoes) {
  const inicio = useRef<{ x: number; y: number; t: number } | null>(null)

  useEffect(() => {
    if (!ativo) return

    function comecou(e: TouchEvent) {
      if (e.touches.length !== 1 || ehZonaProibida(e.target)) { inicio.current = null; return }
      const t = e.touches[0]
      inicio.current = { x: t.clientX, y: t.clientY, t: Date.now() }
    }

    function terminou(e: TouchEvent) {
      const i = inicio.current
      inicio.current = null
      if (!i) return
      const t = e.changedTouches[0]
      if (!t) return
      const dx = t.clientX - i.x
      const dy = t.clientY - i.y
      const dt = Date.now() - i.t
      if (dt > TEMPO_MAXIMO) return
      if (Math.abs(dx) < DISTANCIA_MINIMA) return
      if (Math.abs(dx) < Math.abs(dy) * TOLERANCIA_VERTICAL) return
      if (dx < 0) aoArrastarEsquerda()
      else aoArrastarDireita()
    }

    window.addEventListener('touchstart', comecou, { passive: true })
    window.addEventListener('touchend', terminou, { passive: true })
    return () => {
      window.removeEventListener('touchstart', comecou)
      window.removeEventListener('touchend', terminou)
    }
  }, [aoArrastarEsquerda, aoArrastarDireita, ativo])
}
