import type { Corredor, Produto } from '../lib/tipos'

type Props = {
  corredores: Corredor[]
  /** Corredores ainda por visitar, na ordem da rota. */
  rota: string[]
  /** Corredor do item atual. */
  atual: string | null
  /** Corredores já visitados. */
  feitos: string[]
}

/**
 * Planta da loja desenhada a partir do grafo de corredores.
 * Perímetro (perecíveis) no anel externo; centrais como gôndolas verticais.
 */
export default function Planta({ corredores, rota, atual, feitos }: Props) {
  const perim = corredores.filter((c) => c.perimetro).sort((a, b) => a.ordem - b.ordem)
  const centr = corredores.filter((c) => !c.perimetro).sort((a, b) => a.ordem - b.ordem)

  const L = 300, A = 340
  const gx0 = 62, gx1 = 244            // faixa das gôndolas centrais
  const larg = centr.length ? (gx1 - gx0) / centr.length : 40
  const gl = Math.min(22, larg * 0.52)

  // posição do corredor central i: x do corredor (à esquerda da gôndola)
  const xCorr = (i: number) => gx0 + i * larg + larg / 2
  const yTopo = 54, yBase = 250

  const pos: Record<string, { x: number; y: number }> = {}
  centr.forEach((c, i) => { pos[c.codigo] = { x: xCorr(i), y: 150 } })

  // perímetro: distribui no anel — esquerda, topo, direita
  const n = Math.max(1, perim.length)
  perim.forEach((c, i) => {
    const t = (i + 0.5) / n
    if (t < 1 / 3) {
      const k = t / (1 / 3)
      pos[c.codigo] = { x: 31, y: 84 + k * 132 }        // parede esquerda
    } else if (t < 2 / 3) {
      const k = (t - 1 / 3) / (1 / 3)
      pos[c.codigo] = { x: 78 + k * 144, y: 27 }        // parede do fundo
    } else {
      const k = (t - 2 / 3) / (1 / 3)
      pos[c.codigo] = { x: 269, y: 84 + k * 132 }       // parede direita
    }
  })

  const caminho = [...feitos, ...(atual ? [atual] : []), ...rota]
    .filter((c, i, a) => c && a.indexOf(c) === i)
  const pontos = caminho.map((c) => pos[c]).filter(Boolean)

  const idxAtual = atual ? caminho.indexOf(atual) : -1
  const feitosPts = idxAtual >= 0 ? pontos.slice(0, idxAtual + 1) : pontos
  const faltaPts = idxAtual >= 0 ? pontos.slice(idxAtual) : []

  const linha = (p: { x: number; y: number }[]) =>
    p.map((q) => `${q.x},${q.y}`).join(' ')

  return (
    <svg className="planta" viewBox={`0 0 ${L} ${A}`} role="img"
         aria-label="Planta da loja com o caminho da sua lista.">
      <rect x="8" y="8" width={L - 16} height={A - 16} rx="7"
            fill="var(--papel-2)" stroke="var(--linha)" strokeWidth="1.5" />

      {/* anel de perecíveis */}
      <g fill="color-mix(in srgb, var(--verde) 13%, transparent)">
        <rect x="14" y="60" width="34" height="180" rx="3" />
        <rect x="56" y="14" width="188" height="26" rx="3" />
        <rect x="252" y="60" width="34" height="180" rx="3" />
      </g>

      {/* gôndolas centrais */}
      {centr.map((c, i) => (
        <g key={c.codigo}>
          <rect x={xCorr(i) + (larg - gl) / 2 - 2} y={yTopo + 8} width={gl} height={yBase - yTopo - 8}
                rx="2" fill="var(--papel-3)" stroke="var(--linha)" strokeWidth="1" />
          <text x={xCorr(i) + (larg - gl) / 2 - 2 + gl / 2} y={yBase + 12}
                textAnchor="middle" fontSize="7.5" fontFamily="IBM Plex Mono, monospace"
                fill="var(--tinta-3)">
            {c.codigo}
          </text>
        </g>
      ))}

      {/* caixas e entrada */}
      <g fill="var(--papel-3)" stroke="var(--linha)" strokeWidth="1">
        {[70, 120, 170, 220].map((x) => (
          <rect key={x} x={x} y="278" width="34" height="20" rx="3" />
        ))}
      </g>
      <g fill="var(--tinta-3)" fontSize="7" fontFamily="IBM Plex Mono, monospace" textAnchor="middle">
        <text x="152" y="315">CAIXAS</text>
        <text x="32" y="315">ENTRADA</text>
      </g>

      {faltaPts.length > 1 && (
        <polyline points={linha(faltaPts)} fill="none" stroke="var(--lona)" strokeWidth="2.4"
                  strokeDasharray="5 4" strokeLinejoin="round" strokeLinecap="round" />
      )}
      {feitosPts.length > 1 && (
        <polyline points={linha(feitosPts)} fill="none" stroke="var(--verde)" strokeWidth="2.4"
                  strokeLinejoin="round" strokeLinecap="round" />
      )}

      {caminho.map((cod, i) => {
        const p = pos[cod]
        if (!p) return null
        const eAtual = cod === atual
        const feito = feitos.includes(cod)
        return (
          <g key={cod}>
            <circle cx={p.x} cy={p.y} r={eAtual ? 9 : 7}
                    fill={eAtual ? 'var(--caixote)' : feito ? 'var(--verde)' : 'var(--lona)'} />
            <text x={p.x} y={p.y + 2.8} textAnchor="middle" fontSize={eAtual ? 8.5 : 7.5}
                  fontWeight="700" fill="var(--papel-2)"
                  fontFamily="IBM Plex Mono, monospace">{i + 1}</text>
          </g>
        )
      })}
    </svg>
  )
}
