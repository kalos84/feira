import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { exigeLogin, sair } from '../lib/auth'

const DESTINOS = [
  { rota: '/',      titulo: 'Escolher mercado', dica: 'lojas perto de você' },
  { rota: '/lista', titulo: 'Minha lista',      dica: 'montar e orçar a feira' },
  { rota: '/rota',  titulo: 'Rota da compra',   dica: 'endereço de cada item e o mapa' },
  { rota: '/fim',   titulo: 'Resumo da feira',  dica: 'tempo, previsto e gasto real' },
  { rota: '/loja',  titulo: 'Painel da loja',   dica: 'fila, rupturas e indicadores' },
]

export default function Menu() {
  const nav = useNavigate()
  const { pathname } = useLocation()
  const [aberto, setAberto] = useState(false)

  useEffect(() => { setAberto(false) }, [pathname])

  useEffect(() => {
    function esc(e: KeyboardEvent) { if (e.key === 'Escape') setAberto(false) }
    window.addEventListener('keydown', esc)
    return () => window.removeEventListener('keydown', esc)
  }, [])

  return (
    <>
      <button className="menu-botao" onClick={() => setAberto((a) => !a)}
              aria-expanded={aberto} aria-label={aberto ? 'Fechar menu' : 'Abrir menu'}>
        {aberto ? (
          <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true">
            <path d="M5 5 L15 15 M15 5 L5 15" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
          </svg>
        ) : (
          <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true">
            <path d="M3 6 H17 M3 10 H17 M3 14 H17" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
          </svg>
        )}
      </button>

      {aberto && (
        <>
          <div className="menu-fundo" onClick={() => setAberto(false)} />
          <nav className="menu-folha" aria-label="Navegação do app">
            <span className="eyebrow">Ir para</span>
            {DESTINOS.map((d) => (
              <button key={d.rota} className="menu-item" aria-current={pathname === d.rota}
                      onClick={() => nav(d.rota)}>
                <span className="mi-titulo">{d.titulo}</span>
                <span className="mi-dica">{d.dica}</span>
              </button>
            ))}
            {exigeLogin && (
              <button className="menu-item sair" onClick={() => sair()}>
                <span className="mi-titulo">Sair da conta</span>
                <span className="mi-dica">encerra a sessão neste aparelho</span>
              </button>
            )}
          </nav>
        </>
      )}
    </>
  )
}
