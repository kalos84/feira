import { useCallback, useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useSwipe } from '../lib/useSwipe'

/** A ordem do fluxo. Arrastar para a esquerda avança; para a direita, volta. */
export const PASSOS = ['/', '/lista', '/rota', '/fim', '/loja']

export default function Fluxo({ children }: { children: React.ReactNode }) {
  const nav = useNavigate()
  const { pathname } = useLocation()
  const [direcao, setDirecao] = useState<'frente' | 'tras' | null>(null)
  const [dica, setDica] = useState<string | null>(null)
  const anterior = useRef(pathname)

  const indice = PASSOS.indexOf(pathname)

  const avancar = useCallback(() => {
    if (indice < 0 || indice >= PASSOS.length - 1) {
      setDica('Você já está no último passo')
      return
    }
    const destino = PASSOS[indice + 1]
    // as telas de compra dependem de uma loja escolhida
    if (destino !== '/' && destino !== '/loja') {
      let loja: string | null = null
      try { loja = localStorage.getItem('feira.loja') } catch { /* ignore */ }
      if (!loja) { setDica('Escolha um mercado para continuar'); return }
    }
    setDirecao('frente')
    nav(PASSOS[indice + 1])
  }, [indice, nav])

  const voltar = useCallback(() => {
    if (indice <= 0) {
      setDica('Este é o primeiro passo')
      return
    }
    setDirecao('tras')
    nav(PASSOS[indice - 1])
  }, [indice, nav])

  useSwipe({ aoArrastarEsquerda: avancar, aoArrastarDireita: voltar })

  useEffect(() => {
    if (!dica) return
    const t = setTimeout(() => setDica(null), 1600)
    return () => clearTimeout(t)
  }, [dica])

  useEffect(() => { anterior.current = pathname }, [pathname])

  return (
    <div className={'fluxo' + (direcao ? ` entra-${direcao}` : '')} key={pathname}>
      {children}
      {indice >= 0 && (
        <div className="passos" aria-hidden="true">
          {PASSOS.map((p, i) => (
            <i key={p} className={i === indice ? 'aqui' : ''} />
          ))}
        </div>
      )}
      {dica && <div className="dica-swipe" role="status">{dica}</div>}
    </div>
  )
}
