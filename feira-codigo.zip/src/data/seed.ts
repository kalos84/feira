// Gerado a partir de supabase/seed.sql — usado no modo demo, sem banco.
export const seed = {
  "loja": {
    "nome": "Comper Palmas Sul",
    "endereco": "Av. LO-5, Plano Diretor Sul",
    "cidade": "Palmas",
    "lat": -10.2489,
    "lng": -48.3243,
    "caixas": 8,
    "nota": 4.6,
    "achabilidade": 94
  },
  "corredores": [
    {
      "codigo": "P1",
      "nome": "Hortifrúti",
      "perimetro": true,
      "ordem": 1
    },
    {
      "codigo": "P2",
      "nome": "Padaria",
      "perimetro": true,
      "ordem": 2
    },
    {
      "codigo": "C4",
      "nome": "Mercearia doce",
      "perimetro": false,
      "ordem": 3
    },
    {
      "codigo": "C7",
      "nome": "Massas, molhos e panificação",
      "perimetro": false,
      "ordem": 4
    },
    {
      "codigo": "C9",
      "nome": "Bebidas",
      "perimetro": false,
      "ordem": 5
    },
    {
      "codigo": "C11",
      "nome": "Limpeza",
      "perimetro": false,
      "ordem": 6
    },
    {
      "codigo": "C14",
      "nome": "Higiene e pet",
      "perimetro": false,
      "ordem": 7
    },
    {
      "codigo": "P3",
      "nome": "Açougue",
      "perimetro": true,
      "ordem": 8
    },
    {
      "codigo": "P5",
      "nome": "Laticínios e frios",
      "perimetro": true,
      "ordem": 9
    }
  ],
  "secoes": [
    {
      "corredor": "P1",
      "nome": "Folhosas e legumes",
      "prateleira": 2,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "hortifruti-legume"
      ]
    },
    {
      "corredor": "P1",
      "nome": "Frutas",
      "prateleira": 2,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "hortifruti-fruta"
      ]
    },
    {
      "corredor": "P1",
      "nome": "Ovos",
      "prateleira": 3,
      "lado": "B",
      "ordem": 3,
      "categorias": [
        "ovos"
      ]
    },
    {
      "corredor": "P2",
      "nome": "Pães",
      "prateleira": 3,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "padaria-pao"
      ]
    },
    {
      "corredor": "P2",
      "nome": "Bolos e biscoitos caseiros",
      "prateleira": 3,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "padaria-doce"
      ]
    },
    {
      "corredor": "C4",
      "nome": "Café e achocolatado",
      "prateleira": 3,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "cafe"
      ]
    },
    {
      "corredor": "C4",
      "nome": "Açúcar e adoçante",
      "prateleira": 2,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "acucar"
      ]
    },
    {
      "corredor": "C4",
      "nome": "Biscoitos",
      "prateleira": 3,
      "lado": "B",
      "ordem": 3,
      "categorias": [
        "biscoito"
      ]
    },
    {
      "corredor": "C4",
      "nome": "Cereais matinais",
      "prateleira": 4,
      "lado": "B",
      "ordem": 4,
      "categorias": [
        "cereal"
      ]
    },
    {
      "corredor": "C4",
      "nome": "Doces e sobremesas",
      "prateleira": 3,
      "lado": "B",
      "ordem": 5,
      "categorias": [
        "doce"
      ]
    },
    {
      "corredor": "C7",
      "nome": "Massas",
      "prateleira": 3,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "massa"
      ]
    },
    {
      "corredor": "C7",
      "nome": "Molhos de tomate",
      "prateleira": 2,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "molho"
      ]
    },
    {
      "corredor": "C7",
      "nome": "Farinhas e misturas",
      "prateleira": 3,
      "lado": "A",
      "ordem": 3,
      "categorias": [
        "farinha"
      ]
    },
    {
      "corredor": "C7",
      "nome": "Fermento e confeitaria",
      "prateleira": 3,
      "lado": "A",
      "ordem": 4,
      "categorias": [
        "fermento"
      ]
    },
    {
      "corredor": "C7",
      "nome": "Enlatados",
      "prateleira": 2,
      "lado": "B",
      "ordem": 5,
      "categorias": [
        "enlatado"
      ]
    },
    {
      "corredor": "C7",
      "nome": "Arroz e feijão",
      "prateleira": 1,
      "lado": "B",
      "ordem": 6,
      "categorias": [
        "arroz-feijao"
      ]
    },
    {
      "corredor": "C7",
      "nome": "Óleo, azeite e vinagre",
      "prateleira": 3,
      "lado": "B",
      "ordem": 7,
      "categorias": [
        "oleo"
      ]
    },
    {
      "corredor": "C7",
      "nome": "Temperos e condimentos",
      "prateleira": 4,
      "lado": "B",
      "ordem": 8,
      "categorias": [
        "tempero"
      ]
    },
    {
      "corredor": "C9",
      "nome": "Águas",
      "prateleira": 1,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "agua"
      ]
    },
    {
      "corredor": "C9",
      "nome": "Refrigerantes",
      "prateleira": 2,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "refrigerante"
      ]
    },
    {
      "corredor": "C9",
      "nome": "Sucos",
      "prateleira": 3,
      "lado": "A",
      "ordem": 3,
      "categorias": [
        "suco"
      ]
    },
    {
      "corredor": "C9",
      "nome": "Cervejas",
      "prateleira": 1,
      "lado": "B",
      "ordem": 4,
      "categorias": [
        "cerveja"
      ]
    },
    {
      "corredor": "C11",
      "nome": "Sabão em pó e líquido",
      "prateleira": 2,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "lavanderia"
      ]
    },
    {
      "corredor": "C11",
      "nome": "Amaciantes",
      "prateleira": 3,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "amaciante"
      ]
    },
    {
      "corredor": "C11",
      "nome": "Limpeza geral",
      "prateleira": 3,
      "lado": "B",
      "ordem": 3,
      "categorias": [
        "limpeza"
      ]
    },
    {
      "corredor": "C11",
      "nome": "Descartáveis e papel",
      "prateleira": 4,
      "lado": "B",
      "ordem": 4,
      "categorias": [
        "papel"
      ]
    },
    {
      "corredor": "C14",
      "nome": "Higiene oral",
      "prateleira": 3,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "higiene-oral"
      ]
    },
    {
      "corredor": "C14",
      "nome": "Sabonetes e banho",
      "prateleira": 3,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "banho"
      ]
    },
    {
      "corredor": "C14",
      "nome": "Cabelo",
      "prateleira": 4,
      "lado": "A",
      "ordem": 3,
      "categorias": [
        "cabelo"
      ]
    },
    {
      "corredor": "C14",
      "nome": "Papel higiênico",
      "prateleira": 2,
      "lado": "B",
      "ordem": 4,
      "categorias": [
        "papel-higienico"
      ]
    },
    {
      "corredor": "C14",
      "nome": "Pet",
      "prateleira": 1,
      "lado": "B",
      "ordem": 5,
      "categorias": [
        "pet"
      ]
    },
    {
      "corredor": "P3",
      "nome": "Bovinos",
      "prateleira": 3,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "carne-bovina"
      ]
    },
    {
      "corredor": "P3",
      "nome": "Aves",
      "prateleira": 3,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "aves"
      ]
    },
    {
      "corredor": "P3",
      "nome": "Suínos e embutidos",
      "prateleira": 3,
      "lado": "A",
      "ordem": 3,
      "categorias": [
        "suino"
      ]
    },
    {
      "corredor": "P5",
      "nome": "Leites",
      "prateleira": 3,
      "lado": "A",
      "ordem": 1,
      "categorias": [
        "leite"
      ]
    },
    {
      "corredor": "P5",
      "nome": "Iogurtes",
      "prateleira": 3,
      "lado": "A",
      "ordem": 2,
      "categorias": [
        "iogurte"
      ]
    },
    {
      "corredor": "P5",
      "nome": "Queijos e frios",
      "prateleira": 3,
      "lado": "A",
      "ordem": 3,
      "categorias": [
        "frios"
      ]
    },
    {
      "corredor": "P5",
      "nome": "Manteiga e margarina",
      "prateleira": 2,
      "lado": "A",
      "ordem": 4,
      "categorias": [
        "manteiga"
      ]
    },
    {
      "corredor": "P5",
      "nome": "Congelados",
      "prateleira": 1,
      "lado": "B",
      "ordem": 5,
      "categorias": [
        "congelado"
      ]
    }
  ],
  "produtos": [
    {
      "descricao": "Tomate italiano kg",
      "categoria": "hortifruti-legume",
      "preco": 8.49,
      "estoque": 40
    },
    {
      "descricao": "Cebola branca kg",
      "categoria": "hortifruti-legume",
      "preco": 5.99,
      "estoque": 35
    },
    {
      "descricao": "Batata inglesa kg",
      "categoria": "hortifruti-legume",
      "preco": 6.49,
      "estoque": 50
    },
    {
      "descricao": "Cenoura kg",
      "categoria": "hortifruti-legume",
      "preco": 5.29,
      "estoque": 30
    },
    {
      "descricao": "Alface crespa un",
      "categoria": "hortifruti-legume",
      "preco": 3.99,
      "estoque": 20
    },
    {
      "descricao": "Banana prata kg",
      "categoria": "hortifruti-fruta",
      "preco": 6.99,
      "estoque": 45
    },
    {
      "descricao": "Maçã gala kg",
      "categoria": "hortifruti-fruta",
      "preco": 9.9,
      "estoque": 25
    },
    {
      "descricao": "Mamão formosa kg",
      "categoria": "hortifruti-fruta",
      "preco": 7.49,
      "estoque": 18
    },
    {
      "descricao": "Laranja pera kg",
      "categoria": "hortifruti-fruta",
      "preco": 4.99,
      "estoque": 40
    },
    {
      "descricao": "Ovos brancos 12un",
      "categoria": "ovos",
      "preco": 14.9,
      "estoque": 30
    },
    {
      "descricao": "Pão de forma Pullman 500g",
      "categoria": "padaria-pao",
      "preco": 9.49,
      "estoque": 22
    },
    {
      "descricao": "Pão francês kg",
      "categoria": "padaria-pao",
      "preco": 16.9,
      "estoque": 60
    },
    {
      "descricao": "Pão de queijo congelado 400g",
      "categoria": "padaria-pao",
      "preco": 18.9,
      "estoque": 12
    },
    {
      "descricao": "Bolo de fubá fatia",
      "categoria": "padaria-doce",
      "preco": 7.9,
      "estoque": 8
    },
    {
      "descricao": "Café Três Corações 500g",
      "categoria": "cafe",
      "preco": 18.9,
      "estoque": 26
    },
    {
      "descricao": "Café Pilão 500g",
      "categoria": "cafe",
      "preco": 19.9,
      "estoque": 20
    },
    {
      "descricao": "Achocolatado Nescau 380g",
      "categoria": "cafe",
      "preco": 9.49,
      "estoque": 24
    },
    {
      "descricao": "Açúcar cristal União 1kg",
      "categoria": "acucar",
      "preco": 5.79,
      "estoque": 40
    },
    {
      "descricao": "Adoçante Zero-Cal 100ml",
      "categoria": "acucar",
      "preco": 8.9,
      "estoque": 10
    },
    {
      "descricao": "Biscoito Maizena Piraquê 200g",
      "categoria": "biscoito",
      "preco": 4.99,
      "estoque": 30
    },
    {
      "descricao": "Biscoito Oreo 90g",
      "categoria": "biscoito",
      "preco": 4.49,
      "estoque": 25
    },
    {
      "descricao": "Sucrilhos Kellogg's 300g",
      "categoria": "cereal",
      "preco": 16.9,
      "estoque": 14
    },
    {
      "descricao": "Aveia Quaker 200g",
      "categoria": "cereal",
      "preco": 7.9,
      "estoque": 16
    },
    {
      "descricao": "Chocolate Lacta Ao Leite 80g",
      "categoria": "doce",
      "preco": 7.49,
      "estoque": 30
    },
    {
      "descricao": "Gelatina Royal 20g",
      "categoria": "doce",
      "preco": 3.29,
      "estoque": 20
    },
    {
      "descricao": "Macarrão espaguete Renata 500g",
      "categoria": "massa",
      "preco": 5.49,
      "estoque": 40
    },
    {
      "descricao": "Macarrão parafuso Adria 500g",
      "categoria": "massa",
      "preco": 5.99,
      "estoque": 30
    },
    {
      "descricao": "Lasanha pronta Massa Leve 600g",
      "categoria": "massa",
      "preco": 22.9,
      "estoque": 8
    },
    {
      "descricao": "Molho de tomate Pomarola 340g",
      "categoria": "molho",
      "preco": 4.79,
      "estoque": 45
    },
    {
      "descricao": "Extrato de tomate Elefante 340g",
      "categoria": "molho",
      "preco": 5.49,
      "estoque": 30
    },
    {
      "descricao": "Farinha de trigo Dona Benta 1kg",
      "categoria": "farinha",
      "preco": 6.49,
      "estoque": 28
    },
    {
      "descricao": "Mistura para bolo Dona Benta 450g",
      "categoria": "farinha",
      "preco": 8.9,
      "estoque": 15
    },
    {
      "descricao": "Fermento biológico seco Fleischmann 10g",
      "categoria": "fermento",
      "preco": 4.29,
      "estoque": 4
    },
    {
      "descricao": "Fermento em pó Royal 100g",
      "categoria": "fermento",
      "preco": 6.9,
      "estoque": 12
    },
    {
      "descricao": "Chocolate granulado Dori 150g",
      "categoria": "fermento",
      "preco": 7.49,
      "estoque": 10
    },
    {
      "descricao": "Milho verde Quero 170g",
      "categoria": "enlatado",
      "preco": 3.99,
      "estoque": 26
    },
    {
      "descricao": "Sardinha Gomes da Costa 125g",
      "categoria": "enlatado",
      "preco": 7.9,
      "estoque": 22
    },
    {
      "descricao": "Arroz branco Tio João 5kg",
      "categoria": "arroz-feijao",
      "preco": 32.9,
      "estoque": 30
    },
    {
      "descricao": "Feijão carioca Camil 1kg",
      "categoria": "arroz-feijao",
      "preco": 8.49,
      "estoque": 35
    },
    {
      "descricao": "Óleo de soja Liza 900ml",
      "categoria": "oleo",
      "preco": 7.99,
      "estoque": 40
    },
    {
      "descricao": "Azeite Gallo 500ml",
      "categoria": "oleo",
      "preco": 34.9,
      "estoque": 12
    },
    {
      "descricao": "Vinagre de álcool Castelo 750ml",
      "categoria": "oleo",
      "preco": 4.29,
      "estoque": 18
    },
    {
      "descricao": "Sal refinado Cisne 1kg",
      "categoria": "tempero",
      "preco": 3.49,
      "estoque": 30
    },
    {
      "descricao": "Alho triturado 200g",
      "categoria": "tempero",
      "preco": 9.9,
      "estoque": 12
    },
    {
      "descricao": "Água mineral Crystal 1,5L",
      "categoria": "agua",
      "preco": 3.49,
      "estoque": 60
    },
    {
      "descricao": "Refrigerante Coca-Cola 2L",
      "categoria": "refrigerante",
      "preco": 9.99,
      "estoque": 50
    },
    {
      "descricao": "Refrigerante Guaraná Antarctica 2L",
      "categoria": "refrigerante",
      "preco": 8.49,
      "estoque": 40
    },
    {
      "descricao": "Suco Del Valle uva 1L",
      "categoria": "suco",
      "preco": 9.9,
      "estoque": 20
    },
    {
      "descricao": "Cerveja Skol lata 350ml",
      "categoria": "cerveja",
      "preco": 3.99,
      "estoque": 120
    },
    {
      "descricao": "Sabão em pó Omo 1,6kg",
      "categoria": "lavanderia",
      "preco": 24.9,
      "estoque": 20
    },
    {
      "descricao": "Sabão líquido Ariel 3L",
      "categoria": "lavanderia",
      "preco": 39.9,
      "estoque": 8
    },
    {
      "descricao": "Amaciante Downy 2L",
      "categoria": "amaciante",
      "preco": 22.9,
      "estoque": 12
    },
    {
      "descricao": "Detergente Ypê 500ml",
      "categoria": "limpeza",
      "preco": 2.49,
      "estoque": 50
    },
    {
      "descricao": "Água sanitária Qboa 2L",
      "categoria": "limpeza",
      "preco": 7.49,
      "estoque": 25
    },
    {
      "descricao": "Desinfetante Pinho Sol 500ml",
      "categoria": "limpeza",
      "preco": 8.9,
      "estoque": 18
    },
    {
      "descricao": "Papel toalha Snob 2un",
      "categoria": "papel",
      "preco": 9.9,
      "estoque": 20
    },
    {
      "descricao": "Saco de lixo 50L 10un",
      "categoria": "papel",
      "preco": 7.49,
      "estoque": 15
    },
    {
      "descricao": "Creme dental Colgate 90g",
      "categoria": "higiene-oral",
      "preco": 6.49,
      "estoque": 30
    },
    {
      "descricao": "Escova de dente Oral-B",
      "categoria": "higiene-oral",
      "preco": 9.9,
      "estoque": 18
    },
    {
      "descricao": "Sabonete Dove 90g",
      "categoria": "banho",
      "preco": 4.49,
      "estoque": 40
    },
    {
      "descricao": "Shampoo Seda 325ml",
      "categoria": "cabelo",
      "preco": 14.9,
      "estoque": 16
    },
    {
      "descricao": "Papel higiênico Neve 12un",
      "categoria": "papel-higienico",
      "preco": 27.9,
      "estoque": 18
    },
    {
      "descricao": "Ração Golden cães adultos 3kg",
      "categoria": "pet",
      "preco": 48.9,
      "estoque": 6
    },
    {
      "descricao": "Areia sanitária gatos 4kg",
      "categoria": "pet",
      "preco": 21.9,
      "estoque": 5
    },
    {
      "descricao": "Patinho bovino kg",
      "categoria": "carne-bovina",
      "preco": 42.9,
      "estoque": 15
    },
    {
      "descricao": "Alcatra kg",
      "categoria": "carne-bovina",
      "preco": 49.9,
      "estoque": 12
    },
    {
      "descricao": "Coxa e sobrecoxa kg",
      "categoria": "aves",
      "preco": 12.9,
      "estoque": 25
    },
    {
      "descricao": "Peito de frango kg",
      "categoria": "aves",
      "preco": 19.9,
      "estoque": 20
    },
    {
      "descricao": "Linguiça toscana Seara kg",
      "categoria": "suino",
      "preco": 24.9,
      "estoque": 14
    },
    {
      "descricao": "Bacon fatiado Sadia 250g",
      "categoria": "suino",
      "preco": 16.9,
      "estoque": 10
    },
    {
      "descricao": "Leite integral Italac 1L",
      "categoria": "leite",
      "preco": 5.49,
      "estoque": 80
    },
    {
      "descricao": "Leite desnatado Piracanjuba 1L",
      "categoria": "leite",
      "preco": 5.79,
      "estoque": 40
    },
    {
      "descricao": "Leite condensado Moça 395g",
      "categoria": "leite",
      "preco": 8.49,
      "estoque": 26
    },
    {
      "descricao": "Iogurte natural Danone 170g",
      "categoria": "iogurte",
      "preco": 4.29,
      "estoque": 30
    },
    {
      "descricao": "Muçarela fatiada Tirol 150g",
      "categoria": "frios",
      "preco": 11.9,
      "estoque": 14
    },
    {
      "descricao": "Presunto cozido fatiado 150g",
      "categoria": "frios",
      "preco": 9.9,
      "estoque": 16
    },
    {
      "descricao": "Requeijão Catupiry 200g",
      "categoria": "frios",
      "preco": 12.9,
      "estoque": 20
    },
    {
      "descricao": "Manteiga Aviação 200g",
      "categoria": "manteiga",
      "preco": 18.9,
      "estoque": 15
    },
    {
      "descricao": "Margarina Qualy 500g",
      "categoria": "manteiga",
      "preco": 11.49,
      "estoque": 22
    },
    {
      "descricao": "Creme de leite Piracanjuba 200g",
      "categoria": "congelado",
      "preco": 4.19,
      "estoque": 0
    },
    {
      "descricao": "Pizza congelada Sadia 460g",
      "categoria": "congelado",
      "preco": 21.9,
      "estoque": 9
    }
  ]
} as const
