# FEIRA

Protótipo funcional do app de navegação em loja para supermercados.
PWA em React + Vite + TypeScript, com Supabase opcional.

## Como rodar

```bash
npm install
npm run dev
```

Sem variáveis de ambiente o app sobe em **modo demo**: catálogo, corredores e
seções vêm de `src/data/seed.ts` e o estado fica no `localStorage`. Serve para
demonstrar o fluxo inteiro sem banco nenhum.

## Ligando o banco

1. Crie um projeto no Supabase.
2. No **SQL Editor**, rode `supabase/schema.sql` e depois `supabase/seed.sql`.
3. Copie `.env.example` para `.env` e preencha `VITE_SUPABASE_URL` e
   `VITE_SUPABASE_ANON_KEY` (Project Settings → API).
4. `npm run dev`. O app passa a ler e gravar no Postgres — sem mudar uma linha
   de código: quem decide é `src/lib/dados.ts`.

## Publicar na Vercel

```bash
npm i -g vercel
vercel login
vercel --prod
```

Depois, em Project Settings → Environment Variables, adicione as duas
variáveis do Supabase e refaça o deploy.

## Telas

| Rota | O que é |
|---|---|
| `#/` | Descoberta — mercados próximos por geolocalização, busca por nome |
| `#/lista` | Lista com busca no catálogo e total previsto |
| `#/rota` | Rota ordenada, endereço em 3 níveis, planta da loja, "não encontrei" |
| `#/fim` | Resumo: tempo, previsto x real, itens reportados |
| `#/loja` | PULSO — painel da loja, previsão de caixa, rupturas |

## Arquitetura em uma frase

`src/lib/dados.ts` é a única camada de dados. Ela tem duas implementações por
trás da mesma interface — Supabase e demo local — e o resto do app não sabe
qual está ativa.

## A decisão de modelagem que mais importa

O endereço é da **seção**, não do produto. O produto chega até a seção pela
**categoria** que já vem do ERP (`categoria_secao`). É isso que transforma o
cadastro de 6.000 SKUs em ~130 seções, e o que permite remapear um corredor
inteiro em minutos.

## Mantendo o projeto Supabase acordado

O plano Free pausa um projeto após cerca de 7 dias sem atividade, e retomá-lo
é manual. `.github/workflows/keepalive.yml` resolve isso: uma consulta de uma
linha a cada 3 dias, rodando de graça no GitHub Actions.

Para ativar, em **Settings → Secrets and variables → Actions** do repositório:

| Secret | Valor |
|---|---|
| `SUPABASE_URL` | `https://<ref>.supabase.co` |
| `SUPABASE_ANON_KEY` | a publishable key do projeto |

O workflow também pode ser disparado à mão (`workflow_dispatch`), e falha com
erro visível se o banco não responder — ou seja, ele avisa **antes** de você
descobrir pelo app fora do ar.

Alternativa sem GitHub: um Cron Job da Vercel chamando a mesma URL uma vez por
dia. Só vale se o projeto já estiver publicado lá.
